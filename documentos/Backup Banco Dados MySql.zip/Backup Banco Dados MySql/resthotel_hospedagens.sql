-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hospedagens`
--

DROP TABLE IF EXISTS `hospedagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hospedagens` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `checkin` datetime DEFAULT NULL,
  `checkout` datetime DEFAULT NULL,
  `total_consumo` decimal(10,2) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `funcionario_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `usuario_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `quarto_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `cliente_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `ativo` int(11) DEFAULT NULL,
  `limpeza` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `quarto_id` (`quarto_id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `hospedagens_funcionario_id_foreign_idx` (`funcionario_id`),
  KEY `hospedagens_usuario_id_foreign_idx` (`usuario_id`),
  CONSTRAINT `hospedagens_funcionario_id_foreign_idx` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`),
  CONSTRAINT `hospedagens_ibfk_1` FOREIGN KEY (`quarto_id`) REFERENCES `quartos` (`id`),
  CONSTRAINT `hospedagens_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `hospedagens_usuario_id_foreign_idx` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospedagens`
--

LOCK TABLES `hospedagens` WRITE;
/*!40000 ALTER TABLE `hospedagens` DISABLE KEYS */;
INSERT INTO `hospedagens` VALUES ('01d56c77-a31f-4ff5-8242-4bec1cab0531','2023-11-25 21:29:51','2023-11-25 21:34:09',0.00,0.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'2b9b3bfd-ff78-4364-85ef-a5f1d5c13be1','cf339ccb-fade-4bda-a472-46cb25391841',0,0,'2023-11-25 21:29:51','2023-11-25 21:35:48'),('0cbf1522-ca2f-4167-b744-ddaf22ba47f0','2023-09-25 00:51:38','2023-12-04 23:03:05',10.00,12435.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'0fe23e33-540b-4e69-9d5e-aba9dfedb26f','f7f00fb4-67a6-4995-accf-1c5d4d42fe75',0,0,'2023-09-25 00:51:38','2023-12-04 23:03:25'),('0feb4108-5169-48ca-80b1-d1239e52f2e7','2023-11-25 20:03:04','2023-11-25 20:17:25',NULL,NULL,'25bd68a7-433a-4e95-ab6d-00b8409b9ef8',NULL,'44590dcf-7a06-465a-8af5-0a2c68a8f7d2','f7f00fb4-67a6-4995-accf-1c5d4d42fe75',0,0,'2023-11-25 20:03:04','2023-11-25 20:18:06'),('125c3d24-491e-48ee-b20c-7a74ae9f4169','2023-10-12 00:46:07',NULL,NULL,NULL,NULL,NULL,'c6dfba9f-0669-445f-80d9-edc1e9bf8615','cf339ccb-fade-4bda-a472-46cb25391841',1,0,'2023-10-10 00:46:29','2023-10-10 00:46:29'),('234dd58f-724b-4e99-b0fe-e434d8ae2fa5','2023-11-25 21:36:17','2023-11-25 21:36:43',25.00,25.00,'25bd68a7-433a-4e95-ab6d-00b8409b9ef8',NULL,'a6b21c07-79e1-4c7d-aa15-bcc5a7293d8d','f7f00fb4-67a6-4995-accf-1c5d4d42fe75',0,0,'2023-11-25 21:36:17','2023-11-25 21:38:28'),('4a78edcd-604c-4d51-8921-b902f650123b','2023-11-25 20:58:50','2023-11-25 20:59:15',NULL,NULL,'25bd68a7-433a-4e95-ab6d-00b8409b9ef8',NULL,'44590dcf-7a06-465a-8af5-0a2c68a8f7d2','f7f00fb4-67a6-4995-accf-1c5d4d42fe75',0,0,'2023-11-25 20:58:50','2023-11-25 21:24:36'),('5f2ddb06-6d24-42b4-8f60-9bb3d40b3cbf','2023-12-15 23:00:49','2023-12-04 23:01:44',39.50,1964.50,'25bd68a7-433a-4e95-ab6d-00b8409b9ef8',NULL,'2b9b3bfd-ff78-4364-85ef-a5f1d5c13be1','8',0,0,'2023-12-04 23:00:49','2023-12-04 23:02:54'),('64f97e08-4604-4719-8a3c-236e722785ee','2023-11-25 21:26:57','2023-11-25 21:27:06',NULL,NULL,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'44590dcf-7a06-465a-8af5-0a2c68a8f7d2','cf339ccb-fade-4bda-a472-46cb25391841',0,0,'2023-11-25 21:26:57','2023-11-25 21:27:45'),('950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-09-26 00:52:56','2023-11-24 22:53:19',93.00,15093.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'44590dcf-7a06-465a-8af5-0a2c68a8f7d2','cf339ccb-fade-4bda-a472-46cb25391841',0,0,'2023-09-25 00:52:56','2023-11-24 22:53:39'),('c174a9b3-3efe-4185-9f8b-2608e1949f08','2023-11-25 21:44:27','2023-11-25 21:44:31',0.00,250.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'bc2045c4-fa05-4f27-9904-db77b738c2f3','cf339ccb-fade-4bda-a472-46cb25391841',0,0,'2023-11-25 21:44:27','2023-11-26 23:59:15'),('dc16b1c7-f70b-4724-9b17-d6425d7f8baa','2023-12-05 00:33:13','2023-12-05 00:33:38',58.00,308.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'fb2847ed-b417-4f95-8436-01cab2e62fc5','9',0,0,'2023-12-05 00:33:13','2023-12-05 00:34:07'),('f48690e1-be84-468c-9f15-9636caf34eb6','2023-10-09 22:42:42','2023-11-25 20:56:18',48.50,8273.50,'25bd68a7-433a-4e95-ab6d-00b8409b9ef8',NULL,'40e78928-69e0-495e-b6ee-f4295282e522','f7f00fb4-67a6-4995-accf-1c5d4d42fe75',0,1,'2023-10-09 22:42:42','2023-11-25 20:57:46'),('f6c6323f-f8ef-4e77-befc-7588dc8ab950','2023-12-05 01:55:22','2023-12-05 01:56:01',36.00,286.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'fb2847ed-b417-4f95-8436-01cab2e62fc5','8',0,0,'2023-12-05 01:55:22','2023-12-05 01:56:33'),('f77cec0e-70cf-499c-b6b0-2d2dc64311bc','2023-11-25 21:38:45','2023-11-25 21:42:11',0.00,250.00,'7bbf644b-63cc-4350-868b-36cb80877ab6',NULL,'b29a7a1d-7fe2-4878-bb2b-0cf434510e48','cf339ccb-fade-4bda-a472-46cb25391841',0,0,'2023-11-25 21:38:45','2023-11-25 21:42:59');
/*!40000 ALTER TABLE `hospedagens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:22
