-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produtos_servicos`
--

DROP TABLE IF EXISTS `produtos_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos_servicos` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `tipo` char(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos_servicos`
--

LOCK TABLES `produtos_servicos` WRITE;
/*!40000 ALTER TABLE `produtos_servicos` DISABLE KEYS */;
INSERT INTO `produtos_servicos` VALUES ('17d87b13-7237-429a-9763-8f3eb97d1230','Quarto',NULL,15.00,'S','2023-10-08 19:04:11','2023-10-08 19:04:11'),('1dc08749-7bef-47dc-9821-1205b5c5bdf4','Lavanderia',NULL,10.00,'S','2023-10-08 19:01:25','2023-10-08 19:01:25'),('635a5341-104a-4ca8-b6cc-8adc2cde9910','Coca-Cola',0,7.00,'P','2023-10-08 19:07:16','2023-10-08 19:07:16'),('810cf2bd-98f6-4b74-9ad6-37ca8fc7e7ed','Fanta',15,5.00,'P','2023-10-08 19:07:31','2023-10-08 19:07:31'),('99354f66-4607-437d-af0f-daf94ee404b0','X-Burguer',5,18.50,'P','2023-10-08 19:42:35','2023-10-08 19:42:35'),('aeeb3f5d-c7e6-45d7-a709-638abe59f383','Pizza Calabresa',5,22.00,'P','2023-10-08 19:07:51','2023-10-08 19:07:51'),('b796e1b0-af40-4a4e-81f1-de7b962edaf1','Pizza Portuguesa',7,23.50,'P','2023-10-08 19:38:17','2023-10-08 19:38:17');
/*!40000 ALTER TABLE `produtos_servicos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:21
