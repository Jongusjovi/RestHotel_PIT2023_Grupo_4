-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `itens_menus`
--

DROP TABLE IF EXISTS `itens_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_menus` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `menu_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `caminho` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itens_menus_menu_id_foreign_idx` (`menu_id`),
  CONSTRAINT `itens_menus_menu_id_foreign_idx` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_menus`
--

LOCK TABLES `itens_menus` WRITE;
/*!40000 ALTER TABLE `itens_menus` DISABLE KEYS */;
INSERT INTO `itens_menus` VALUES ('02540db7-43bc-4781-b280-973c9d2b14cd','Funções','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroFuncoes','2023-11-07 00:57:25','2023-11-07 00:57:25'),('05202ee2-2cae-416d-af81-f8ba8d4ea06a','Contas a pagar','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','relatorioContasPagar','2023-11-26 16:41:32','2023-11-26 16:41:32'),('1d6811a7-13da-4a50-9285-bc78f640ce5a','Produtos','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroProdutos','2023-11-07 00:58:08','2023-11-07 00:58:08'),('26483e2c-adb5-4ab3-9bb2-496720b76d2f','Fornecedores','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroFornecedores','2023-11-07 00:57:17','2023-11-07 00:57:17'),('52709bfc-c469-4fac-b30a-4f1f0e369746','Níveis de Usuários','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroNiveis','2023-11-07 00:56:51','2023-11-07 00:56:51'),('53cccfe1-4d67-495f-b321-ad8fea3471db','Usuários','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroUsuarios','2023-11-17 00:50:39','2023-11-17 00:50:39'),('57f4adc0-543c-4209-9baf-01dcb46d7284','Hospedagens','748e08d3-a1a3-4826-a3e8-873c3d978390','relatorioHospedagens','2023-11-26 16:40:18','2023-11-26 16:40:18'),('68563b56-7591-42d5-bddb-1c41a4d961c0','Tipos de Quarto','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroTiposQuarto','2023-11-07 00:59:45','2023-11-07 00:59:45'),('7a740d43-b433-4f56-8405-b775ca6a8966','Permissões','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroPermissoes','2023-11-07 00:56:45','2023-11-07 00:56:45'),('813d4591-0d60-456c-90d2-7663d40dd62b','Depesas','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroDespesas','2023-11-26 01:16:09','2023-11-26 01:16:09'),('872cb49c-f5e2-4596-b450-da46063769c4','Hospedagens','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroHospedagens','2023-11-07 00:58:01','2023-11-07 00:58:01'),('92bae33d-714d-4c64-a338-ea0b03395351','Funcionários','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroFuncionarios','2023-11-07 00:57:35','2023-11-07 00:57:35'),('a263efd0-cee3-471e-a45e-6846912285a5','Reservas de Hospedagens','748e08d3-a1a3-4826-a3e8-873c3d978390','relatorioReservas','2023-11-26 16:41:57','2023-11-26 16:41:57'),('a665bb54-4084-4536-9779-e63b783bc68e','Consumos de Funcionários','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroConsumosFuncionarios','2023-11-07 00:57:43','2023-11-07 00:57:43'),('a6dd032d-9a09-42ca-98be-c23ee0951dd2','Categorias de Depesas','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroCategoriasDespesas','2023-11-25 23:33:28','2023-11-25 23:33:28'),('b7249e56-5352-4e36-8798-832b02b41f81','Produtos','748e08d3-a1a3-4826-a3e8-873c3d978390','relatorioProdutos','2023-11-26 16:42:19','2023-11-26 16:42:19'),('c72426de-c96a-445b-8b43-bb525e1ef376','Serviços','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroServicos','2023-11-07 00:56:28','2023-11-07 00:56:28'),('cea5e1ff-6c3d-4a18-a9c6-ab6e7e67e0db','Consumos de Clientes','748e08d3-a1a3-4826-a3e8-873c3d978390','relatorioConsumosClientes','2023-11-26 16:41:03','2023-11-26 16:41:03'),('db4a45da-d782-494e-8df1-ae98ff551b96','Quartos','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroQuartos','2023-11-07 00:58:16','2023-11-07 00:58:16'),('e032c7b5-9037-4596-8f8a-89618d97ba42','Reservas','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroReservaHospedagens','2023-11-07 00:57:54','2023-11-07 00:57:54'),('f1556efa-6f99-4f4a-afad-d012aad4a1e1','Clientes','d3d3016c-eb86-4e51-83c0-1a9ab5e1b982','cadastroClientes','2023-11-07 00:57:12','2023-11-07 00:57:12');
/*!40000 ALTER TABLE `itens_menus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:22
