-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cpf` varchar(255) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `uf` varchar(255) DEFAULT NULL,
  `cep` varchar(255) DEFAULT NULL,
  `telefone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES ('1','123.456.789-01','João Silva','Rua A, 123','Centro','Cidade A','UF1','12345-678','(11) 1234-5678','joao@email.com','1990-01-01','2023-01-01 00:00:00','2023-01-01 00:00:00'),('10','012.345.678-90','Fernanda Silva','Avenida J, 987','Bairro V','Cidade J','UF10','01234-567','(10) 9876-5432','fernanda@email.com','1993-07-18','2023-01-10 00:00:00','2023-01-10 00:00:00'),('2','234.567.890-12','Maria Oliveira','Avenida B, 456','Bairro X','Cidade B','UF2','23456-789','(22) 9876-5432','maria@email.com','1985-05-15','2023-01-02 00:00:00','2023-01-02 00:00:00'),('3','345.678.901-23','Carlos Santos','Rua C, 789','Centro','Cidade C','UF3','34567-890','(33) 5555-4444','carlos@email.com','1982-08-20','2023-01-03 00:00:00','2023-01-03 00:00:00'),('4','456.789.012-34','Ana Pereira','Avenida D, 987','Bairro Y','Cidade D','UF4','45678-901','(44) 8765-4321','ana@email.com','1995-12-10','2023-01-04 00:00:00','2023-01-04 00:00:00'),('5','567.890.123-45','José Oliveira','Rua E, 654','Centro','Cidade E','UF5','56789-012','(55) 2345-6789','jose@email.com','1988-03-25','2023-01-05 00:00:00','2023-01-05 00:00:00'),('6','678.901.234-56','Amanda Silva','Avenida F, 321','Bairro Z','Cidade F','UF6','67890-123','(66) 9876-5432','amanda@email.com','1992-06-30','2023-01-06 00:00:00','2023-01-06 00:00:00'),('7','789.012.345-67','Ricardo Santos','Rua G, 987','Centro','Cidade G','UF7','78901-234','(77) 5555-4444','ricardo@email.com','1980-09-15','2023-01-07 00:00:00','2023-01-07 00:00:00'),('8','890.123.456-78','Mariana Pereira','Avenida H, 654','Bairro W','Cidade H','UF8','89012-345','(88) 8765-4321','mariana@email.com','1998-02-05','2023-01-08 00:00:00','2023-01-08 00:00:00'),('9','901.234.567-89','Pedro Oliveira','Rua I, 321','Centro','Cidade I','UF9','90123-456','(99) 2345-6789','pedro@email.com','1987-04-12','2023-01-09 00:00:00','2023-01-09 00:00:00'),('cf339ccb-fade-4bda-a472-46cb25391841','918.366.545-53','Alexandre Fernandez','Rua Maria Godoy Canholi','Parque Imperial','PRESIDENTE PRUDENTE','SP','19028200','18996857803','alexandre@hotmail.com','1988-02-08','2023-09-01 01:47:04','2023-09-25 00:49:25'),('f7f00fb4-67a6-4995-accf-1c5d4d42fe75','735.335.430-56','Gustavo de Lima Oliveira','Rua Maria Godoy Canholi','Parque Imperial','PRESIDENTE PRUDENTE','SP','19028-200','18996857803','gustavo.lima.oliveira@hotmail.com','1980-07-25','2023-09-20 19:47:07','2023-12-05 03:02:03');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:20
