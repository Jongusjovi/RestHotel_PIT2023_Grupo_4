-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consumos_funcionarios`
--

DROP TABLE IF EXISTS `consumos_funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumos_funcionarios` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `datahora` timestamp NOT NULL DEFAULT current_timestamp(),
  `proser_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `funcionario_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `proser_id` (`proser_id`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `consumos_funcionarios_ibfk_1` FOREIGN KEY (`proser_id`) REFERENCES `produtos_servicos` (`id`),
  CONSTRAINT `consumos_funcionarios_ibfk_2` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumos_funcionarios`
--

LOCK TABLES `consumos_funcionarios` WRITE;
/*!40000 ALTER TABLE `consumos_funcionarios` DISABLE KEYS */;
INSERT INTO `consumos_funcionarios` VALUES ('19321a30-e8f5-4a40-8abb-f6a875f5fd94',4,'2023-10-09 22:45:52','aeeb3f5d-c7e6-45d7-a709-638abe59f383','25bd68a7-433a-4e95-ab6d-00b8409b9ef8','2023-10-09 22:45:52','2023-10-09 22:45:52'),('7890b5e7-c90e-49e5-bdc2-8b31dd08e4a4',4,'2023-10-09 22:44:27','aeeb3f5d-c7e6-45d7-a709-638abe59f383','25bd68a7-433a-4e95-ab6d-00b8409b9ef8','2023-10-09 22:44:27','2023-10-09 22:44:27'),('991978e4-923b-48ac-b316-8e9104c4a313',1,'2023-10-09 14:28:10','aeeb3f5d-c7e6-45d7-a709-638abe59f383','7bbf644b-63cc-4350-868b-36cb80877ab6','2023-10-09 14:28:10','2023-10-09 14:28:10'),('a208f1fe-5b6c-4a18-bf49-50a21c9a0571',1,'2023-10-09 01:48:42','635a5341-104a-4ca8-b6cc-8adc2cde9910','7bbf644b-63cc-4350-868b-36cb80877ab6','2023-10-09 01:48:42','2023-10-09 01:48:42'),('d7dfd1ab-df5c-4fc1-8e41-49ff8106082d',1,'2023-10-09 22:44:19','99354f66-4607-437d-af0f-daf94ee404b0','25bd68a7-433a-4e95-ab6d-00b8409b9ef8','2023-10-09 22:44:19','2023-10-09 22:44:19'),('f3f90c7a-fad5-4498-8bf5-06b780f61644',1,'2023-12-05 00:34:29','b796e1b0-af40-4a4e-81f1-de7b962edaf1','25bd68a7-433a-4e95-ab6d-00b8409b9ef8','2023-12-05 00:34:29','2023-12-05 00:34:29');
/*!40000 ALTER TABLE `consumos_funcionarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:20
