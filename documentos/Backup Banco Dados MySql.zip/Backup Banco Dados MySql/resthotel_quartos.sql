-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quartos`
--

DROP TABLE IF EXISTS `quartos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quartos` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `quartotipo_id` int(11) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `quartotipo_id` (`quartotipo_id`),
  CONSTRAINT `quartos_ibfk_1` FOREIGN KEY (`quartotipo_id`) REFERENCES `quartostipos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quartos`
--

LOCK TABLES `quartos` WRITE;
/*!40000 ALTER TABLE `quartos` DISABLE KEYS */;
INSERT INTO `quartos` VALUES ('0fe23e33-540b-4e69-9d5e-aba9dfedb26f','Temático',92663274,3,0,'2023-09-25 00:45:17','2023-12-04 23:03:25'),('2b9b3bfd-ff78-4364-85ef-a5f1d5c13be1','Temático',92663274,6,0,'2023-09-25 00:45:39','2023-12-04 23:02:54'),('40e78928-69e0-495e-b6ee-f4295282e522','Temático',92663274,5,0,'2023-09-25 00:45:35','2023-11-25 20:57:57'),('44590dcf-7a06-465a-8af5-0a2c68a8f7d2','Temático',378,10,0,'2023-09-25 00:46:19','2023-11-25 21:27:45'),('5f238ac0-062e-4d1f-97ca-8ab12a068e1e','Temático',92663275,8,0,'2023-09-25 00:45:59','2023-09-25 00:45:59'),('84b763f7-04e8-4e2f-b5d4-6bb10ad78c71','Quarto colorido com vista para o mar',92663274,2,0,'2023-09-01 01:12:55','2023-09-27 22:23:10'),('a6b21c07-79e1-4c7d-aa15-bcc5a7293d8d','Temático',92663274,4,0,'2023-09-25 00:45:30','2023-11-25 21:38:28'),('b29a7a1d-7fe2-4878-bb2b-0cf434510e48','Temático',378,12,0,'2023-09-25 00:46:26','2023-11-25 21:42:59'),('b98524be-562c-4a9d-a96a-3ac2173e9963','Temático',92663275,7,0,'2023-09-25 00:45:54','2023-09-25 00:45:54'),('bc2045c4-fa05-4f27-9904-db77b738c2f3','Quarto do primeiro andar',378,1,0,'2023-08-31 23:57:12','2023-11-26 23:59:15'),('c6dfba9f-0669-445f-80d9-edc1e9bf8615','Temático',92663275,9,1,'2023-09-25 00:46:03','2023-10-10 00:46:29'),('fb2847ed-b417-4f95-8436-01cab2e62fc5','Temático',378,11,0,'2023-09-25 00:46:22','2023-12-05 01:56:33');
/*!40000 ALTER TABLE `quartos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:21
