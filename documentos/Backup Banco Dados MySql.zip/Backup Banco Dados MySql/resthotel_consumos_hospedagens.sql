-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: resthotel
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consumos_hospedagens`
--

DROP TABLE IF EXISTS `consumos_hospedagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumos_hospedagens` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `datahora` timestamp NOT NULL DEFAULT current_timestamp(),
  `proser_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `hospedagem_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `proser_id` (`proser_id`),
  KEY `hospedagem_id` (`hospedagem_id`),
  CONSTRAINT `consumos_hospedagens_ibfk_1` FOREIGN KEY (`proser_id`) REFERENCES `produtos_servicos` (`id`),
  CONSTRAINT `consumos_hospedagens_ibfk_2` FOREIGN KEY (`hospedagem_id`) REFERENCES `hospedagens` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumos_hospedagens`
--

LOCK TABLES `consumos_hospedagens` WRITE;
/*!40000 ALTER TABLE `consumos_hospedagens` DISABLE KEYS */;
INSERT INTO `consumos_hospedagens` VALUES ('11034808-df8b-4f5c-8f9e-e5b4ace0d312',1,'2023-10-08 21:20:17','aeeb3f5d-c7e6-45d7-a709-638abe59f383','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 21:20:17','2023-10-08 21:20:17'),('1524a77b-33d4-422b-8e66-a2b47ada6395',1,'2023-11-25 20:59:10','17d87b13-7237-429a-9763-8f3eb97d1230','4a78edcd-604c-4d51-8921-b902f650123b','2023-11-25 20:59:10','2023-11-25 20:59:10'),('1a232888-6449-4e22-9047-f6df2febb6ee',1,'2023-11-25 21:36:36','1dc08749-7bef-47dc-9821-1205b5c5bdf4','234dd58f-724b-4e99-b0fe-e434d8ae2fa5','2023-11-25 21:36:36','2023-11-25 21:36:36'),('1c097972-c17a-4795-b18e-936f835922cf',1,'2023-10-08 21:18:12','810cf2bd-98f6-4b74-9ad6-37ca8fc7e7ed','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 21:18:12','2023-10-08 21:18:12'),('24ccd0ab-58e8-497f-952c-660b1ad8148b',1,'2023-10-08 21:39:45','1dc08749-7bef-47dc-9821-1205b5c5bdf4','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 21:39:45','2023-10-08 21:39:45'),('2cd3847b-bed1-4d7e-97b7-0acccab9a6fb',1,'2023-10-08 20:16:09','b796e1b0-af40-4a4e-81f1-de7b962edaf1','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 20:16:09','2023-10-08 20:16:09'),('4c7a25b2-4751-4bba-b97b-6ed91270b2b6',1,'2023-10-09 22:42:59','1dc08749-7bef-47dc-9821-1205b5c5bdf4','f48690e1-be84-468c-9f15-9636caf34eb6','2023-10-09 22:42:59','2023-10-09 22:42:59'),('751ae8a1-9fd9-473c-9293-1e4111314d79',1,'2023-11-25 20:59:05','635a5341-104a-4ca8-b6cc-8adc2cde9910','4a78edcd-604c-4d51-8921-b902f650123b','2023-11-25 20:59:05','2023-11-25 20:59:05'),('76dde475-cbbe-4bd8-a53a-cf5afe95e172',1,'2023-10-08 21:13:37','99354f66-4607-437d-af0f-daf94ee404b0','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 21:13:37','2023-10-08 21:13:37'),('7c32cf1d-7d87-43e9-aefa-f44ac5ef8bf5',1,'2023-11-25 20:55:40','17d87b13-7237-429a-9763-8f3eb97d1230','f48690e1-be84-468c-9f15-9636caf34eb6','2023-11-25 20:55:40','2023-11-25 20:55:40'),('7dc80320-6510-4697-b0bf-9f824c9cc464',1,'2023-11-25 21:36:40','17d87b13-7237-429a-9763-8f3eb97d1230','234dd58f-724b-4e99-b0fe-e434d8ae2fa5','2023-11-25 21:36:40','2023-11-25 21:36:40'),('9c9469ca-7786-43ab-849b-1f3bd4ad8091',2,'2023-12-05 00:33:26','635a5341-104a-4ca8-b6cc-8adc2cde9910','dc16b1c7-f70b-4724-9b17-d6425d7f8baa','2023-12-05 00:33:26','2023-12-05 00:33:26'),('9d1d20aa-8fec-4018-9092-2ebe48cdaf8d',1,'2023-10-09 22:41:44','1dc08749-7bef-47dc-9821-1205b5c5bdf4','0cbf1522-ca2f-4167-b744-ddaf22ba47f0','2023-10-09 22:41:44','2023-10-09 22:41:44'),('b6dbbd46-4322-47bb-ba1d-5001aa4a082e',2,'2023-12-05 00:33:36','aeeb3f5d-c7e6-45d7-a709-638abe59f383','dc16b1c7-f70b-4724-9b17-d6425d7f8baa','2023-12-05 00:33:36','2023-12-05 00:33:36'),('c370c51e-6bb4-49dd-bb1a-0028363224b4',3,'2023-12-04 23:01:29','635a5341-104a-4ca8-b6cc-8adc2cde9910','5f2ddb06-6d24-42b4-8f60-9bb3d40b3cbf','2023-12-04 23:01:29','2023-12-04 23:01:29'),('d5b81697-0f7b-4468-8738-861d24cf7a23',3,'2023-12-05 01:55:51','635a5341-104a-4ca8-b6cc-8adc2cde9910','f6c6323f-f8ef-4e77-befc-7588dc8ab950','2023-12-05 01:55:51','2023-12-05 01:55:51'),('d8450dd7-138a-40e6-8cf6-4b42ff1d82ff',1,'2023-12-04 23:01:21','99354f66-4607-437d-af0f-daf94ee404b0','5f2ddb06-6d24-42b4-8f60-9bb3d40b3cbf','2023-12-04 23:01:21','2023-12-04 23:01:21'),('de089391-60d2-40f3-8f1a-b50818fb9b31',1,'2023-12-05 01:55:42','17d87b13-7237-429a-9763-8f3eb97d1230','f6c6323f-f8ef-4e77-befc-7588dc8ab950','2023-12-05 01:55:42','2023-12-05 01:55:42'),('ebf8c734-5c5a-497d-970a-25bcd2c85498',2,'2023-10-08 21:10:46','635a5341-104a-4ca8-b6cc-8adc2cde9910','950ecf46-cf2f-4126-8ff3-74a446f568c3','2023-10-08 21:10:46','2023-10-08 21:10:46'),('fa2e6726-c0c5-40eb-ac4e-89620f10833f',1,'2023-11-25 20:55:53','b796e1b0-af40-4a4e-81f1-de7b962edaf1','f48690e1-be84-468c-9f15-9636caf34eb6','2023-11-25 20:55:53','2023-11-25 20:55:53');
/*!40000 ALTER TABLE `consumos_hospedagens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-05  0:04:21
